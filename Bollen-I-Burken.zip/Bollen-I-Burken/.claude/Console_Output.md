﻿ Collision detected and corrected: Object
 [Game] Key down: ArrowUp -> forward 
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 [Game] Key down: ArrowUp -> forward 
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 [Game] Key down: ArrowUp -> forward 
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 🎧 Hearing Check: Distance=11.89m, EffectiveRange=9.26m, PlayerSpeed=0.063, SoundLevel=0.487
 [Game] Key down: ArrowUp -> forward 
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 [Game] Key down: ArrowUp -> forward 
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 [Game] Key down: ArrowUp -> forward 
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 [Game] Key down: ArrowUp -> forward 
 Collision detected and corrected: Object
 [Game] Key down: ArrowUp -> forward 
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 [Game] Key down: ArrowUp -> forward 
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 [Game] Key down: ArrowUp -> forward 
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 [Game] Key down: ArrowUp -> forward 
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 [Game] Key down: ArrowUp -> forward 
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 [Game] Key down: ArrowUp -> forward 
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 [Game] Key down: ArrowUp -> forward 
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 [Game] Key down: ArrowUp -> forward 
 Collision detected and corrected: Object
 [Game] Key down: ArrowUp -> forward 
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 [Game] Key down: ArrowUp -> forward 
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 [Game] Key down: ArrowUp -> forward 
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 [Game] Key down: ArrowUp -> forward 
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 [Game] Key down: ArrowUp -> forward 
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 [Game] Key down: ArrowUp -> forward 
 Collision detected and corrected: Object
 [Game] Key down: ArrowUp -> forward 
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 [Game] Key down: ArrowUp -> forward 
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 [Game] Key down: ArrowUp -> forward 
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 [Game] Key down: ArrowUp -> forward 
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 [Game] Key down: ArrowUp -> forward 
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 [Game] Key down: ArrowUp -> forward 
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 [VISION DEBUG] Object
 [Game] Key down: ArrowUp -> forward 
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 [Game] Key down: ArrowUp -> forward 
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 [Game] Key down: ArrowUp -> forward 
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 [Game] Key down: ArrowUp -> forward 
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 [Game] Key down: ArrowLeft -> left 
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 🎧 Hearing Check: Distance=16.36m, EffectiveRange=15.10m, PlayerSpeed=0.103, SoundLevel=0.795
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 [Game] Key down: ArrowDown -> backward 
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 [Game] Key down: ArrowDown -> backward 
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 [Game] Key down: ArrowDown -> backward 
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 [Game] Key down: ArrowDown -> backward 
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 [Game] Key down: ArrowDown -> backward 
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 🎧 Hearing Check: Distance=18.70m, EffectiveRange=6.83m, PlayerSpeed=0.047, SoundLevel=0.360
 [Game] Key down: ArrowDown -> backward 
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 [Game] Key down: ArrowRight -> right 
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 [Game] Key down: ArrowRight -> right 
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 [Game] Key down: ArrowRight -> right 
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 [Game] Key down: ArrowRight -> right 
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 [Game] Key down: ArrowRight -> right 
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 [Game] Key down: ArrowRight -> right 
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 [Game] Key down: ArrowRight -> right 
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 [Game] Key down: ArrowRight -> right 
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 [Game] Key down: ArrowRight -> right 
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 [Game] Key down: ArrowRight -> right 
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 [Game] Key down: ArrowRight -> right 
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 [Game] Key down: ArrowRight -> right 
 Collision detected and corrected: Object
 [Game] Key down: ArrowRight -> right 
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 [Game] Key down: ArrowRight -> right 
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 [Game] Key down: ArrowRight -> right 
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 🎧 Hearing Check: Distance=14.82m, EffectiveRange=13.61m, PlayerSpeed=0.093, SoundLevel=0.716
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 [Game] Key down: ArrowRight -> right 
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 [Game] Key down: ArrowRight -> right 
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 [Game] Key down: ArrowRight -> right 
 Collision detected and corrected: Object
 [Game] Key down: ArrowRight -> right 
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
  [Game Error] AI Hunter 391 update failed: 
error @ utils.js:167
  Hunter 391 update failed: 
update @ ai-system.js:83
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 [AVOID] Distance: 0.86m, Turn: LEFT, Urgency: 0.71
  [Game Error] AI Hunter 391 update failed: 
error @ utils.js:167
  Hunter 391 update failed: 
update @ ai-system.js:83
 [Game] Key down: ArrowRight -> right 
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 [AVOID] Distance: 0.86m, Turn: LEFT, Urgency: 0.71
  [Game Error] AI Hunter 391 update failed: 
error @ utils.js:167
  Hunter 391 update failed: 
update @ ai-system.js:83
 Collision detected and corrected: Object
 [AVOID] Distance: 0.85m, Turn: LEFT, Urgency: 0.72
  [Game Error] AI Hunter 391 update failed: 
error @ utils.js:167
  Hunter 391 update failed: 
update @ ai-system.js:83
 [Game] Key down: ArrowRight -> right 
 Collision detected and corrected: Object
 [AVOID] Distance: 0.86m, Turn: LEFT, Urgency: 0.71
  [Game Error] AI Hunter 391 update failed: 
error @ utils.js:167
  Hunter 391 update failed: 
update @ ai-system.js:83
 Collision detected and corrected: Object
  [Game Error] AI Hunter 391 update failed: 
error @ utils.js:167
  Hunter 391 update failed: 
update @ ai-system.js:83
 Collision detected and corrected: Object
  [Game Error] AI Hunter 391 update failed: 
error @ utils.js:167
  Hunter 391 update failed: 
update @ ai-system.js:83
 [Game] Key down: ArrowRight -> right 
 Collision detected and corrected: Object
  [Game Error] AI Hunter 391 update failed: 
error @ utils.js:167
  Hunter 391 update failed: 
update @ ai-system.js:83
 Collision detected and corrected: Object
  [Game Error] AI Hunter 391 update failed: 
error @ utils.js:167
  Hunter 391 update failed: 
update @ ai-system.js:83
 [Game] Key down: ArrowRight -> right 
 Collision detected and corrected: Object
  [Game Error] AI Hunter 391 update failed: 
error @ utils.js:167
  Hunter 391 update failed: 
update @ ai-system.js:83
 Collision detected and corrected: Object
  [Game Error] AI Hunter 391 update failed: 
error @ utils.js:167
  Hunter 391 update failed: 
update @ ai-system.js:83
 [Game] Key down: ArrowRight -> right 
 Collision detected and corrected: Object
  [Game Error] AI Hunter 391 update failed: 
error @ utils.js:167
  Hunter 391 update failed: 
update @ ai-system.js:83
 Collision detected and corrected: Object
  [Game Error] AI Hunter 391 update failed: 
error @ utils.js:167
  Hunter 391 update failed: 
update @ ai-system.js:83
 [Game] Key down: ArrowRight -> right 
 Collision detected and corrected: Object
 Collision detected and corrected: Object
  [Game Error] AI Hunter 391 update failed: 
error @ utils.js:167
  Hunter 391 update failed: 
update @ ai-system.js:83
 Collision detected and corrected: Object
  [Game Error] AI Hunter 391 update failed: 
error @ utils.js:167
  Hunter 391 update failed: 
update @ ai-system.js:83
 [Game] Key down: ArrowRight -> right 
 Collision detected and corrected: Object
  [Game Error] AI Hunter 391 update failed: 
error @ utils.js:167
  Hunter 391 update failed: 
update @ ai-system.js:83
 [Game] Key down: ArrowRight -> right 
 Collision detected and corrected: Object
  [Game Error] AI Hunter 391 update failed: 
error @ utils.js:167
  Hunter 391 update failed: 
update @ ai-system.js:83
 Collision detected and corrected: Object
  [Game Error] AI Hunter 391 update failed: 
error @ utils.js:167
  Hunter 391 update failed: 
update @ ai-system.js:83
 Collision detected and corrected: Object
  [Game Error] AI Hunter 391 update failed: 
error @ utils.js:167
  Hunter 391 update failed: 
update @ ai-system.js:83
 Collision detected and corrected: Object
  [Game Error] AI Hunter 391 update failed: 
error @ utils.js:167
  Hunter 391 update failed: 
update @ ai-system.js:83
 Collision detected and corrected: Object
  [Game Error] AI Hunter 391 update failed: 
error @ utils.js:167
  Hunter 391 update failed: 
update @ ai-system.js:83
 Collision detected and corrected: Object
  [Game Error] AI Hunter 391 update failed: 
error @ utils.js:167
  Hunter 391 update failed: 
update @ ai-system.js:83
 Collision detected and corrected: Object
  [Game Error] AI Hunter 391 update failed: 
error @ utils.js:167
  Hunter 391 update failed: 
update @ ai-system.js:83
 Collision detected and corrected: Object
  [Game Error] AI Hunter 391 update failed: 
error @ utils.js:167
  Hunter 391 update failed: 
update @ ai-system.js:83
 Collision detected and corrected: Object
  [Game Error] AI Hunter 391 update failed: 
error @ utils.js:167
  Hunter 391 update failed: 
update @ ai-system.js:83
 Collision detected and corrected: Object
  [Game Error] AI Hunter 391 update failed: 
error @ utils.js:167
  Hunter 391 update failed: 
update @ ai-system.js:83
 Collision detected and corrected: Object
  [Game Error] AI Hunter 391 update failed: 
error @ utils.js:167
  Hunter 391 update failed: 
update @ ai-system.js:83
 Collision detected and corrected: Object
  [Game Error] AI Hunter 391 update failed: 
error @ utils.js:167
  Hunter 391 update failed: 
update @ ai-system.js:83
 Collision detected and corrected: Object
  [Game Error] AI Hunter 391 update failed: 
error @ utils.js:167
  Hunter 391 update failed: 
update @ ai-system.js:83
 Collision detected and corrected: Object
  [Game Error] AI Hunter 391 update failed: 
error @ utils.js:167
  Hunter 391 update failed: 
update @ ai-system.js:83
 Collision detected and corrected: Object
  [Game Error] AI Hunter 391 update failed: 
error @ utils.js:167
  Hunter 391 update failed: 
update @ ai-system.js:83
 Collision detected and corrected: Object
  [Game Error] AI Hunter 391 update failed: 
error @ utils.js:167
  Hunter 391 update failed: 
update @ ai-system.js:83
 Collision detected and corrected: Object
  [Game Error] AI Hunter 391 update failed: 
error @ utils.js:167
  Hunter 391 update failed: 
update @ ai-system.js:83
 Collision detected and corrected: Object
  [Game Error] AI Hunter 391 update failed: 
error @ utils.js:167
  Hunter 391 update failed: 
update @ ai-system.js:83
 Collision detected and corrected: Object
  [Game Error] AI Hunter 391 update failed: 
error @ utils.js:167
  Hunter 391 update failed: 
update @ ai-system.js:83
 Collision detected and corrected: Object
  [Game Error] AI Hunter 391 update failed: 
error @ utils.js:167
  Hunter 391 update failed: 
update @ ai-system.js:83
 Collision detected and corrected: Object
  [Game Error] AI Hunter 391 update failed: 
error @ utils.js:167
  Hunter 391 update failed: 
update @ ai-system.js:83
 Collision detected and corrected: Object
  [Game Error] AI Hunter 391 update failed: 
error @ utils.js:167
  Hunter 391 update failed: 
update @ ai-system.js:83
 Collision detected and corrected: Object
  [Game Error] AI Hunter 391 update failed: 
error @ utils.js:167
  Hunter 391 update failed: 
update @ ai-system.js:83
 Collision detected and corrected: Object
  [Game Error] AI Hunter 391 update failed: 
error @ utils.js:167
  Hunter 391 update failed: 
update @ ai-system.js:83
 Collision detected and corrected: Object
  [Game Error] AI Hunter 391 update failed: 
error @ utils.js:167
  Hunter 391 update failed: 
update @ ai-system.js:83
 Collision detected and corrected: Object
  [Game Error] AI Hunter 391 update failed: 
error @ utils.js:167
  Hunter 391 update failed: 
update @ ai-system.js:83
 Collision detected and corrected: Object
  [Game Error] AI Hunter 391 update failed: 
error @ utils.js:167
  Hunter 391 update failed: 
update @ ai-system.js:83
 Collision detected and corrected: Object
  [Game Error] AI Hunter 391 update failed: 
error @ utils.js:167
  Hunter 391 update failed: 
update @ ai-system.js:83
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 🎧 Hearing Check: Distance=10.47m, EffectiveRange=3.17m, PlayerSpeed=0.022, SoundLevel=0.167
 [Game] Player in vision cone but line of sight blocked by obstacle 
 [Game] Key down: ArrowUp -> forward 
 [Game] Player in vision cone but line of sight blocked by obstacle 
 [Game] Player in vision cone but line of sight blocked by obstacle 
 [Game] Player in vision cone but line of sight blocked by obstacle 
 [Game] Player in vision cone but line of sight blocked by obstacle 
 [Game] Player in vision cone but line of sight blocked by obstacle 
 [Game] Player in vision cone but line of sight blocked by obstacle 
 [Game] Player in vision cone but line of sight blocked by obstacle 
 [Game] Player in vision cone but line of sight blocked by obstacle 
 [Game] Player in vision cone but line of sight blocked by obstacle 
 [Game] Player in vision cone but line of sight blocked by obstacle 
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 Collision detected and corrected: Object
 [Game] Key down: ArrowUp -> forward 
 Collision detected and corrected: Object
 [Game] Key down: ArrowUp -> forward 
 Collision detected and corrected: Object
 [Game] Key down: ArrowUp -> forward 
 Collision detected and corrected: Object
  [Game Error] AI Hunter 391 update failed: 
error @ utils.js:167
  Hunter 391 update failed: 
update @ ai-system.js:83
 [Game] Key down: ArrowUp -> forward 
 Collision detected and corrected: Object
 [Game] Player in vision cone but line of sight blocked by obstacle 
  [Game Error] AI Hunter 391 update failed: 
error @ utils.js:167
  Hunter 391 update failed: 
update @ ai-system.js:83
 [Game] Player in vision cone but line of sight blocked by obstacle 
 🎧 Hearing Check: Distance=9.63m, EffectiveRange=9.96m, PlayerSpeed=0.068, SoundLevel=0.524
  [Game Error] AI Hunter 391 update failed: 
error @ utils.js:167
  Hunter 391 update failed: 
update @ ai-system.js:83
 [Game] Key down: ArrowUp -> forward 
 Collision detected and corrected: Object
 [Game] Player in vision cone but line of sight blocked by obstacle 
  [Game Error] AI Hunter 391 update failed: 
error @ utils.js:167
  Hunter 391 update failed: 
update @ ai-system.js:83
 [Game] Player in vision cone but line of sight blocked by obstacle 
  [Game Error] AI Hunter 391 update failed: 
error @ utils.js:167
  Hunter 391 update failed: 
update @ ai-system.js:83
 [Game] Key down: ArrowUp -> forward 
 Collision detected and corrected: Object
 [Game] Player in vision cone but line of sight blocked by obstacle 
  [Game Error] AI Hunter 391 update failed: 
error @ utils.js:167
  Hunter 391 update failed: 
update @ ai-system.js:83
 [Game] Key down: ArrowUp -> forward 
 [Game] Player in vision cone but line of sight blocked by obstacle 
  [Game Error] AI Hunter 391 update failed: 
error @ utils.js:167
  Hunter 391 update failed: 
update @ ai-system.js:83
 Collision detected and corrected: Object
 [Game] Player in vision cone but line of sight blocked by obstacle 
  [Game Error] AI Hunter 391 update failed: 
error @ utils.js:167
  Hunter 391 update failed: 
update @ ai-system.js:83
 [Game] Key down: ArrowUp -> forward 
 [Game] Player in vision cone but line of sight blocked by obstacle 
  [Game Error] AI Hunter 391 update failed: 
error @ utils.js:167
  Hunter 391 update failed: 
update @ ai-system.js:83
 Collision detected and corrected: Object
 [Game] Player in vision cone but line of sight blocked by obstacle 
  [Game Error] AI Hunter 391 update failed: 
error @ utils.js:167
  Hunter 391 update failed: 
update @ ai-system.js:83
 [Game] Key down: ArrowUp -> forward 
 [Game] Player in vision cone but line of sight blocked by obstacle 
  [Game Error] AI Hunter 391 update failed: 
error @ utils.js:167
  Hunter 391 update failed: 
update @ ai-system.js:83
 Collision detected and corrected: Object
 [Game] Player in vision cone but line of sight blocked by obstacle 
  [Game Error] AI Hunter 391 update failed: 
error @ utils.js:167
  Hunter 391 update failed: 
update @ ai-system.js:83
 [Game] Player in vision cone but line of sight blocked by obstacle 
  [Game Error] AI Hunter 391 update failed: 
error @ utils.js:167
  Hunter 391 update failed: 
update @ ai-system.js:83
 [Game] Key down: ArrowUp -> forward 
 Collision detected and corrected: Object
 [Game] Player in vision cone but line of sight blocked by obstacle 
  [Game Error] AI Hunter 391 update failed: 
error @ utils.js:167
  Hunter 391 update failed: 
update @ ai-system.js:83
 [Game] Player in vision cone but line of sight blocked by obstacle 
  [Game Error] AI Hunter 391 update failed: 
error @ utils.js:167
  Hunter 391 update failed: 
update @ ai-system.js:83
 [Game] Key down: ArrowUp -> forward 
 [Game] Player in vision cone but line of sight blocked by obstacle 
  [Game Error] AI Hunter 391 update failed: 
error @ utils.js:167
  Hunter 391 update failed: 
update @ ai-system.js:83
 [Game] Player in vision cone but line of sight blocked by obstacle 
  [Game Error] AI Hunter 391 update failed: 
error @ utils.js:167
  Hunter 391 update failed: 
update @ ai-system.js:83
 [Game] Key down: ArrowUp -> forward 
 [Game] Player in vision cone but line of sight blocked by obstacle 
  [Game Error] AI Hunter 391 update failed: 
error @ utils.js:167
  Hunter 391 update failed: 
update @ ai-system.js:83
 [Game] Key down: ArrowUp -> forward 
 [Game] Player in vision cone but line of sight blocked by obstacle 
  [Game Error] AI Hunter 391 update failed: 
error @ utils.js:167
  Hunter 391 update failed: 
update @ ai-system.js:83
 [Game] Player in vision cone but line of sight blocked by obstacle 
  [Game Error] AI Hunter 391 update failed: 
error @ utils.js:167
  Hunter 391 update failed: 
update @ ai-system.js:83
 [Game] Key down: ArrowUp -> forward 
 [Game] Player in vision cone but line of sight blocked by obstacle 
  [Game Error] AI Hunter 391 update failed: 
error @ utils.js:167
  Hunter 391 update failed: 
update @ ai-system.js:83
 [Game] Player in vision cone but line of sight blocked by obstacle 
  [Game Error] AI Hunter 391 update failed: 
error @ utils.js:167
  Hunter 391 update failed: 
update @ ai-system.js:83
 [Game] Key down: ArrowUp -> forward 
 [Game] Player in vision cone but line of sight blocked by obstacle 
  [Game Error] AI Hunter 391 update failed: 
error @ utils.js:167
  Hunter 391 update failed: 
update @ ai-system.js:83
 [Game] Player in vision cone but line of sight blocked by obstacle 
  [Game Error] AI Hunter 391 update failed: 
error @ utils.js:167
  Hunter 391 update failed: 
update @ ai-system.js:83
 [Game] Key down: ArrowUp -> forward 
 [Game] Player in vision cone but line of sight blocked by obstacle 
  [Game Error] AI Hunter 391 update failed: 
error @ utils.js:167
  Hunter 391 update failed: 
update @ ai-system.js:83
 [Game] Player in vision cone but line of sight blocked by obstacle 
  [Game Error] AI Hunter 391 update failed: 
error @ utils.js:167
  Hunter 391 update failed: 
update @ ai-system.js:83
 [Game] Key down: ArrowUp -> forward 
 [Game] Player in vision cone but line of sight blocked by obstacle 
  [Game Error] AI Hunter 391 update failed: 
error @ utils.js:167
  Hunter 391 update failed: 
update @ ai-system.js:83
 [Game] Player in vision cone but line of sight blocked by obstacle 
  [Game Error] AI Hunter 391 update failed: 
error @ utils.js:167
  Hunter 391 update failed: 
update @ ai-system.js:83
 [Game] Player in vision cone but line of sight blocked by obstacle 
  [Game Error] AI Hunter 391 update failed: 
error @ utils.js:167
  Hunter 391 update failed: 
update @ ai-system.js:83
 [Game] Key down: ArrowUp -> forward 
 [Game] Player in vision cone but line of sight blocked by obstacle 
  [Game Error] AI Hunter 391 update failed: 
error @ utils.js:167
  Hunter 391 update failed: 
update @ ai-system.js:83
 [Game] Player in vision cone but line of sight blocked by obstacle 
  [Game Error] AI Hunter 391 update failed: 
error @ utils.js:167
  Hunter 391 update failed: 
update @ ai-system.js:83
 [Game] Key down: ArrowUp -> forward 
 [Game] Player in vision cone but line of sight blocked by obstacle 
  [Game Error] AI Hunter 391 update failed: 
error @ utils.js:167
  Hunter 391 update failed: 
update @ ai-system.js:83
 [Game] Player in vision cone but line of sight blocked by obstacle 
  [Game Error] AI Hunter 391 update failed: 
error @ utils.js:167
  Hunter 391 update failed: 
update @ ai-system.js:83
 [Game] Key down: ArrowUp -> forward 
 [Game] Player in vision cone but line of sight blocked by obstacle 
  [Game Error] AI Hunter 391 update failed: 
error @ utils.js:167
  Hunter 391 update failed: 
update @ ai-system.js:83
 [Game] Key down: ArrowUp -> forward 
 [Game] Player in vision cone but line of sight blocked by obstacle 
  [Game Error] AI Hunter 391 update failed: 
error @ utils.js:167
  Hunter 391 update failed: 
update @ ai-system.js:83
 [Game] Player in vision cone but line of sight blocked by obstacle 
  [Game Error] AI Hunter 391 update failed: 
error @ utils.js:167
  Hunter 391 update failed: 
update @ ai-system.js:83
 [Game] Key down: ArrowUp -> forward 
 [Game] Player in vision cone but line of sight blocked by obstacle 
  [Game Error] AI Hunter 391 update failed: 
error @ utils.js:167
  Hunter 391 update failed: 
update @ ai-system.js:83
 [Game] Player in vision cone but line of sight blocked by obstacle 
  [Game Error] AI Hunter 391 update failed: 
error @ utils.js:167
  Hunter 391 update failed: 
update @ ai-system.js:83
 [Game] Key down: ArrowUp -> forward 
 [Game] Player in vision cone but line of sight blocked by obstacle 
  [Game Error] AI Hunter 391 update failed: 
error @ utils.js:167
  Hunter 391 update failed: 
update @ ai-system.js:83
 [Game] Player in vision cone but line of sight blocked by obstacle 
  [Game Error] AI Hunter 391 update failed: 
error @ utils.js:167
  Hunter 391 update failed: 
update @ ai-system.js:83
 [Game] Key down: ArrowUp -> forward 
 [VISION DEBUG] Object
 [Game] Player in vision cone but line of sight blocked by obstacle 
  [Game Error] AI Hunter 391 update failed: 
error @ utils.js:167
  Hunter 391 update failed: 
update @ ai-system.js:83
 [Game] Player in vision cone but line of sight blocked by obstacle 
  [Game Error] AI Hunter 391 update failed: 
error @ utils.js:167
  Hunter 391 update failed: 
update @ ai-system.js:83
 [Game] Player in vision cone but line of sight blocked by obstacle 
  [Game Error] AI Hunter 391 update failed: 
error @ utils.js:167
  Hunter 391 update failed: 
update @ ai-system.js:83
 [Game] Key down: ArrowUp -> forward 
 [Game] Player in vision cone but line of sight blocked by obstacle 
  [Game Error] AI Hunter 391 update failed: 
error @ utils.js:167
  Hunter 391 update failed: 
update @ ai-system.js:83
 [Game] Player in vision cone but line of sight blocked by obstacle 
  [Game Error] AI Hunter 391 update failed: 
error @ utils.js:167
  Hunter 391 update failed: 
update @ ai-system.js:83
 [Game] Player in vision cone but line of sight blocked by obstacle 
  [Game Error] AI Hunter 391 update failed: 
error @ utils.js:167
  Hunter 391 update failed: 
update @ ai-system.js:83
 [Game] Player in vision cone but line of sight blocked by obstacle 
  [Game Error] AI Hunter 391 update failed: 
error @ utils.js:167
  Hunter 391 update failed: 
update @ ai-system.js:83
 [Game] Player in vision cone but line of sight blocked by obstacle 
 [Game] Player in vision cone but line of sight blocked by obstacle 
 [Game] Player in vision cone but line of sight blocked by obstacle 
 🎧 Hearing Check: Distance=12.29m, EffectiveRange=0.00m, PlayerSpeed=0.000, SoundLevel=0.000
 [Game] Key down: ArrowLeft -> left 
 [VISION DEBUG] Object
 [Game] Key down: ArrowUp -> forward 
 🎧 Hearing Check: Distance=12.92m, EffectiveRange=7.33m, PlayerSpeed=0.050, SoundLevel=0.386
 [Game] Key down: ArrowUp -> forward 
 [Game] Key down: ArrowUp -> forward 
 [Game] Key down: ArrowUp -> forward 
 [Game] Key down: ArrowUp -> forward 
 [Game] Key down: ArrowUp -> forward 
 [Game] Key down: ArrowUp -> forward 
 [Game] Key down: ArrowUp -> forward 
 [VISION DEBUG] Object
 [Game] Key down: ArrowUp -> forward 
 [GUARD] Checking obstacle 268/348
 [Game] Key down: ArrowUp -> forward 
 [Game] Key down: ArrowUp -> forward 
 [Game] Key down: ArrowUp -> forward 
 [Game] Key down: ArrowUp -> forward 
 [Game] Key down: ArrowLeft -> left 
 [VISION DEBUG] Object
 [VISION DEBUG] Object
 [GUARD] Checking obstacle 269/348
 🎧 Hearing Check: Distance=18.02m, EffectiveRange=14.16m, PlayerSpeed=0.097, SoundLevel=0.745
 [Game] Key down: ArrowLeft -> left 
 [Game] Key down: ArrowLeft -> left 
 [Game] Key down: ArrowLeft -> left 
 [Game] Key down: ArrowLeft -> left 
 [Game] Key down: ArrowLeft -> left 
 [Game] Key down: ArrowLeft -> left 
 [Game] Key down: ArrowLeft -> left 
 [Game] Key down: ArrowLeft -> left 
 [GUARD] Checking obstacle 271/348
 [Game] Key down: ArrowLeft -> left 
 [Game] Key down: ArrowLeft -> left 
 [Game] Key down: ArrowLeft -> left 
 [Game] Key down: ArrowLeft -> left 
 [Game] Key down: ArrowLeft -> left 
 [Game] Key down: ArrowLeft -> left 
 [Game] Key down: ArrowLeft -> left 
 [Game] Key down: ArrowLeft -> left 
 [Game] Key down: ArrowLeft -> left 
 [GUARD] Checking obstacle 272/348
 [Game] Key down: ArrowDown -> backward 
 [GUARD] Checking obstacle 273/348
 [Game] Key down: ArrowRight -> right 
 🎧 Hearing Check: Distance=22.34m, EffectiveRange=4.65m, PlayerSpeed=0.032, SoundLevel=0.245
 [GUARD] Checking obstacle 274/348
 [Game] Key down: ArrowRight -> right 
 [Game] Key down: ArrowRight -> right 
 [Game] Key down: ArrowRight -> right 
 [Game] Key down: ArrowRight -> right 
 [Game] Key down: ArrowRight -> right 
 [GUARD] Checking obstacle 275/348
 [Game] Key down: ArrowRight -> right 
 [Game] Key down: ArrowRight -> right 
 [Game] Key down: ArrowRight -> right 
 [Game] Key down: ArrowRight -> right 
 [Game] Key down: ArrowRight -> right 
utils.js:158 [Game] Key down: ArrowDown -> backward 
ai-system.js:162 🎧 Hearing Check: Distance=19.73m, EffectiveRange=10.99m, PlayerSpeed=0.075, SoundLevel=0.579
can-guard-strategy.js:194 [GUARD] Checking obstacle 276/348
utils.js:158 [Game] Key down: ArrowLeft -> left 
can-guard-strategy.js:194 [GUARD] Checking obstacle 277/348
can-guard-strategy.js:194 [GUARD] Checking obstacle 279/348
ai-system.js:162 🎧 Hearing Check: Distance=15.14m, EffectiveRange=11.95m, PlayerSpeed=0.082, SoundLevel=0.629
utils.js:158 [Game] Key down: ArrowLeft -> left 
can-guard-strategy.js:194 [GUARD] Checking obstacle 280/348
utils.js:167  [Game Error] AI Hunter 391 update failed: ReferenceError: transform is not defined
    at AISystem.updateHearing (ai-system.js:192:25)
    at AISystem.updateHunter (ai-system.js:119:18)
    at AISystem.update (ai-system.js:80:26)
    at GameEngine.tick (game-engine.js:97:36)
    at GameEngine.update (game-engine.js:64:22)
    at gameLoop (main.js:208:24)
error @ utils.js:167
ai-system.js:83  Hunter 391 update failed: ReferenceError: transform is not defined
    at AISystem.updateHearing (ai-system.js:192:25)
    at AISystem.updateHunter (ai-system.js:119:18)
    at AISystem.update (ai-system.js:80:26)
    at GameEngine.tick (game-engine.js:97:36)
    at GameEngine.update (game-engine.js:64:22)
    at gameLoop (main.js:208:24)
update @ ai-system.js:83
utils.js:158 [Game] AI spotted player! Reacting... 
utils.js:167  [Game Error] AI Hunter 391 update failed: ReferenceError: transform is not defined
    at AISystem.updateHearing (ai-system.js:192:25)
    at AISystem.updateHunter (ai-system.js:119:18)
    at AISystem.update (ai-system.js:80:26)
    at GameEngine.tick (game-engine.js:97:36)
    at GameEngine.update (game-engine.js:64:22)
    at gameLoop (main.js:208:24)
error @ utils.js:167
ai-system.js:83  Hunter 391 update failed: ReferenceError: transform is not defined
    at AISystem.updateHearing (ai-system.js:192:25)
    at AISystem.updateHunter (ai-system.js:119:18)
    at AISystem.update (ai-system.js:80:26)
    at GameEngine.tick (game-engine.js:97:36)
    at GameEngine.update (game-engine.js:64:22)
    at gameLoop (main.js:208:24)
update @ ai-system.js:83
utils.js:167  [Game Error] AI Hunter 391 update failed: ReferenceError: transform is not defined
    at AISystem.updateHearing (ai-system.js:192:25)
    at AISystem.updateHunter (ai-system.js:119:18)
    at AISystem.update (ai-system.js:80:26)
    at GameEngine.tick (game-engine.js:97:36)
    at GameEngine.update (game-engine.js:64:22)
    at gameLoop (main.js:208:24)
error @ utils.js:167
ai-system.js:83  Hunter 391 update failed: ReferenceError: transform is not defined
    at AISystem.updateHearing (ai-system.js:192:25)
    at AISystem.updateHunter (ai-system.js:119:18)
    at AISystem.update (ai-system.js:80:26)
    at GameEngine.tick (game-engine.js:97:36)
    at GameEngine.update (game-engine.js:64:22)
    at gameLoop (main.js:208:24)
update @ ai-system.js:83
utils.js:167  [Game Error] AI Hunter 391 update failed: ReferenceError: transform is not defined
    at AISystem.updateHearing (ai-system.js:192:25)
    at AISystem.updateHunter (ai-system.js:119:18)
    at AISystem.update (ai-system.js:80:26)
    at GameEngine.tick (game-engine.js:97:36)
    at GameEngine.update (game-engine.js:64:22)
    at gameLoop (main.js:208:24)
error @ utils.js:167
ai-system.js:83  Hunter 391 update failed: ReferenceError: transform is not defined
    at AISystem.updateHearing (ai-system.js:192:25)
    at AISystem.updateHunter (ai-system.js:119:18)
    at AISystem.update (ai-system.js:80:26)
    at GameEngine.tick (game-engine.js:97:36)
    at GameEngine.update (game-engine.js:64:22)
    at gameLoop (main.js:208:24)
update @ ai-system.js:83
utils.js:167  [Game Error] AI Hunter 391 update failed: ReferenceError: transform is not defined
    at AISystem.updateHearing (ai-system.js:192:25)
    at AISystem.updateHunter (ai-system.js:119:18)
    at AISystem.update (ai-system.js:80:26)
    at GameEngine.tick (game-engine.js:97:36)
    at GameEngine.update (game-engine.js:64:22)
    at gameLoop (main.js:208:24)
error @ utils.js:167
ai-system.js:83  Hunter 391 update failed: ReferenceError: transform is not defined
    at AISystem.updateHearing (ai-system.js:192:25)
    at AISystem.updateHunter (ai-system.js:119:18)
    at AISystem.update (ai-system.js:80:26)
    at GameEngine.tick (game-engine.js:97:36)
    at GameEngine.update (game-engine.js:64:22)
    at gameLoop (main.js:208:24)
update @ ai-system.js:83
utils.js:167  [Game Error] AI Hunter 391 update failed: ReferenceError: transform is not defined
    at AISystem.updateHearing (ai-system.js:192:25)
    at AISystem.updateHunter (ai-system.js:119:18)
    at AISystem.update (ai-system.js:80:26)
    at GameEngine.tick (game-engine.js:97:36)
    at GameEngine.update (game-engine.js:64:22)
    at gameLoop (main.js:208:24)
error @ utils.js:167
ai-system.js:83  Hunter 391 update failed: ReferenceError: transform is not defined
    at AISystem.updateHearing (ai-system.js:192:25)
    at AISystem.updateHunter (ai-system.js:119:18)
    at AISystem.update (ai-system.js:80:26)
    at GameEngine.tick (game-engine.js:97:36)
    at GameEngine.update (game-engine.js:64:22)
    at gameLoop (main.js:208:24)
update @ ai-system.js:83
utils.js:167  [Game Error] AI Hunter 391 update failed: ReferenceError: transform is not defined
    at AISystem.updateHearing (ai-system.js:192:25)
    at AISystem.updateHunter (ai-system.js:119:18)
    at AISystem.update (ai-system.js:80:26)
    at GameEngine.tick (game-engine.js:97:36)
    at GameEngine.update (game-engine.js:64:22)
    at gameLoop (main.js:208:24)
error @ utils.js:167
ai-system.js:83  Hunter 391 update failed: ReferenceError: transform is not defined
    at AISystem.updateHearing (ai-system.js:192:25)
    at AISystem.updateHunter (ai-system.js:119:18)
    at AISystem.update (ai-system.js:80:26)
    at GameEngine.tick (game-engine.js:97:36)
    at GameEngine.update (game-engine.js:64:22)
    at gameLoop (main.js:208:24)
update @ ai-system.js:83
utils.js:167  [Game Error] AI Hunter 391 update failed: ReferenceError: transform is not defined
    at AISystem.updateHearing (ai-system.js:192:25)
    at AISystem.updateHunter (ai-system.js:119:18)
    at AISystem.update (ai-system.js:80:26)
    at GameEngine.tick (game-engine.js:97:36)
    at GameEngine.update (game-engine.js:64:22)
    at gameLoop (main.js:208:24)
error @ utils.js:167
ai-system.js:83  Hunter 391 update failed: ReferenceError: transform is not defined
    at AISystem.updateHearing (ai-system.js:192:25)
    at AISystem.updateHunter (ai-system.js:119:18)
    at AISystem.update (ai-system.js:80:26)
    at GameEngine.tick (game-engine.js:97:36)
    at GameEngine.update (game-engine.js:64:22)
    at gameLoop (main.js:208:24)
update @ ai-system.js:83
utils.js:167  [Game Error] AI Hunter 391 update failed: ReferenceError: transform is not defined
    at AISystem.updateHearing (ai-system.js:192:25)
    at AISystem.updateHunter (ai-system.js:119:18)
    at AISystem.update (ai-system.js:80:26)
    at GameEngine.tick (game-engine.js:97:36)
    at GameEngine.update (game-engine.js:64:22)
    at gameLoop (main.js:208:24)
error @ utils.js:167
ai-system.js:83  Hunter 391 update failed: ReferenceError: transform is not defined
    at AISystem.updateHearing (ai-system.js:192:25)
    at AISystem.updateHunter (ai-system.js:119:18)
    at AISystem.update (ai-system.js:80:26)
    at GameEngine.tick (game-engine.js:97:36)
    at GameEngine.update (game-engine.js:64:22)
    at gameLoop (main.js:208:24)
update @ ai-system.js:83
utils.js:167  [Game Error] AI Hunter 391 update failed: ReferenceError: transform is not defined
    at AISystem.updateHearing (ai-system.js:192:25)
    at AISystem.updateHunter (ai-system.js:119:18)
    at AISystem.update (ai-system.js:80:26)
    at GameEngine.tick (game-engine.js:97:36)
    at GameEngine.update (game-engine.js:64:22)
    at gameLoop (main.js:208:24)
error @ utils.js:167
ai-system.js:83  Hunter 391 update failed: ReferenceError: transform is not defined
    at AISystem.updateHearing (ai-system.js:192:25)
    at AISystem.updateHunter (ai-system.js:119:18)
    at AISystem.update (ai-system.js:80:26)
    at GameEngine.tick (game-engine.js:97:36)
    at GameEngine.update (game-engine.js:64:22)
    at gameLoop (main.js:208:24)
update @ ai-system.js:83
utils.js:167  [Game Error] AI Hunter 391 update failed: ReferenceError: transform is not defined
    at AISystem.updateHearing (ai-system.js:192:25)
    at AISystem.updateHunter (ai-system.js:119:18)
    at AISystem.update (ai-system.js:80:26)
    at GameEngine.tick (game-engine.js:97:36)
    at GameEngine.update (game-engine.js:64:22)
    at gameLoop (main.js:208:24)
error @ utils.js:167
ai-system.js:83  Hunter 391 update failed: ReferenceError: transform is not defined
    at AISystem.updateHearing (ai-system.js:192:25)
    at AISystem.updateHunter (ai-system.js:119:18)
    at AISystem.update (ai-system.js:80:26)
    at GameEngine.tick (game-engine.js:97:36)
    at GameEngine.update (game-engine.js:64:22)
    at gameLoop (main.js:208:24)
update @ ai-system.js:83
utils.js:167  [Game Error] AI Hunter 391 update failed: ReferenceError: transform is not defined
    at AISystem.updateHearing (ai-system.js:192:25)
    at AISystem.updateHunter (ai-system.js:119:18)
    at AISystem.update (ai-system.js:80:26)
    at GameEngine.tick (game-engine.js:97:36)
    at GameEngine.update (game-engine.js:64:22)
    at gameLoop (main.js:208:24)
error @ utils.js:167
ai-system.js:83  Hunter 391 update failed: ReferenceError: transform is not defined
    at AISystem.updateHearing (ai-system.js:192:25)
    at AISystem.updateHunter (ai-system.js:119:18)
    at AISystem.update (ai-system.js:80:26)
    at GameEngine.tick (game-engine.js:97:36)
    at GameEngine.update (game-engine.js:64:22)
    at gameLoop (main.js:208:24)
update @ ai-system.js:83
utils.js:167  [Game Error] AI Hunter 391 update failed: ReferenceError: transform is not defined
    at AISystem.updateHearing (ai-system.js:192:25)
    at AISystem.updateHunter (ai-system.js:119:18)
    at AISystem.update (ai-system.js:80:26)
    at GameEngine.tick (game-engine.js:97:36)
    at GameEngine.update (game-engine.js:64:22)
    at gameLoop (main.js:208:24)
error @ utils.js:167
ai-system.js:83  Hunter 391 update failed: ReferenceError: transform is not defined
    at AISystem.updateHearing (ai-system.js:192:25)
    at AISystem.updateHunter (ai-system.js:119:18)
    at AISystem.update (ai-system.js:80:26)
    at GameEngine.tick (game-engine.js:97:36)
    at GameEngine.update (game-engine.js:64:22)
    at gameLoop (main.js:208:24)
update @ ai-system.js:83
utils.js:158 [Game] AI JUMPS in surprise! 
utils.js:167  [Game Error] AI Hunter 391 update failed: ReferenceError: transform is not defined
    at AISystem.updateHearing (ai-system.js:192:25)
    at AISystem.updateHunter (ai-system.js:119:18)
    at AISystem.update (ai-system.js:80:26)
    at GameEngine.tick (game-engine.js:97:36)
    at GameEngine.update (game-engine.js:64:22)
    at gameLoop (main.js:208:24)
error @ utils.js:167
ai-system.js:83  Hunter 391 update failed: ReferenceError: transform is not defined
    at AISystem.updateHearing (ai-system.js:192:25)
    at AISystem.updateHunter (ai-system.js:119:18)
    at AISystem.update (ai-system.js:80:26)
    at GameEngine.tick (game-engine.js:97:36)
    at GameEngine.update (game-engine.js:64:22)
    at gameLoop (main.js:208:24)
update @ ai-system.js:83
utils.js:167  [Game Error] AI Hunter 391 update failed: ReferenceError: transform is not defined
    at AISystem.updateHearing (ai-system.js:192:25)
    at AISystem.updateHunter (ai-system.js:119:18)
    at AISystem.update (ai-system.js:80:26)
    at GameEngine.tick (game-engine.js:97:36)
    at GameEngine.update (game-engine.js:64:22)
    at gameLoop (main.js:208:24)
error @ utils.js:167
ai-system.js:83  Hunter 391 update failed: ReferenceError: transform is not defined
    at AISystem.updateHearing (ai-system.js:192:25)
    at AISystem.updateHunter (ai-system.js:119:18)
    at AISystem.update (ai-system.js:80:26)
    at GameEngine.tick (game-engine.js:97:36)
    at GameEngine.update (game-engine.js:64:22)
    at gameLoop (main.js:208:24)
update @ ai-system.js:83
utils.js:167  [Game Error] AI Hunter 391 update failed: ReferenceError: transform is not defined
    at AISystem.updateHearing (ai-system.js:192:25)
    at AISystem.updateHunter (ai-system.js:119:18)
    at AISystem.update (ai-system.js:80:26)
    at GameEngine.tick (game-engine.js:97:36)
    at GameEngine.update (game-engine.js:64:22)
    at gameLoop (main.js:208:24)
error @ utils.js:167
ai-system.js:83  Hunter 391 update failed: ReferenceError: transform is not defined
    at AISystem.updateHearing (ai-system.js:192:25)
    at AISystem.updateHunter (ai-system.js:119:18)
    at AISystem.update (ai-system.js:80:26)
    at GameEngine.tick (game-engine.js:97:36)
    at GameEngine.update (game-engine.js:64:22)
    at gameLoop (main.js:208:24)
update @ ai-system.js:83
utils.js:167  [Game Error] AI Hunter 391 update failed: ReferenceError: transform is not defined
    at AISystem.updateHearing (ai-system.js:192:25)
    at AISystem.updateHunter (ai-system.js:119:18)
    at AISystem.update (ai-system.js:80:26)
    at GameEngine.tick (game-engine.js:97:36)
    at GameEngine.update (game-engine.js:64:22)
    at gameLoop (main.js:208:24)
error @ utils.js:167
ai-system.js:83  Hunter 391 update failed: ReferenceError: transform is not defined
    at AISystem.updateHearing (ai-system.js:192:25)
    at AISystem.updateHunter (ai-system.js:119:18)
    at AISystem.update (ai-system.js:80:26)
    at GameEngine.tick (game-engine.js:97:36)
    at GameEngine.update (game-engine.js:64:22)
    at gameLoop (main.js:208:24)
update @ ai-system.js:83
utils.js:167  [Game Error] AI Hunter 391 update failed: ReferenceError: transform is not defined
    at AISystem.updateHearing (ai-system.js:192:25)
    at AISystem.updateHunter (ai-system.js:119:18)
    at AISystem.update (ai-system.js:80:26)
    at GameEngine.tick (game-engine.js:97:36)
    at GameEngine.update (game-engine.js:64:22)
    at gameLoop (main.js:208:24)
error @ utils.js:167
ai-system.js:83  Hunter 391 update failed: ReferenceError: transform is not defined
    at AISystem.updateHearing (ai-system.js:192:25)
    at AISystem.updateHunter (ai-system.js:119:18)
    at AISystem.update (ai-system.js:80:26)
    at GameEngine.tick (game-engine.js:97:36)
    at GameEngine.update (game-engine.js:64:22)
    at gameLoop (main.js:208:24)
update @ ai-system.js:83
utils.js:167  [Game Error] AI Hunter 391 update failed: ReferenceError: transform is not defined
    at AISystem.updateHearing (ai-system.js:192:25)
    at AISystem.updateHunter (ai-system.js:119:18)
    at AISystem.update (ai-system.js:80:26)
    at GameEngine.tick (game-engine.js:97:36)
    at GameEngine.update (game-engine.js:64:22)
    at gameLoop (main.js:208:24)
error @ utils.js:167
ai-system.js:83  Hunter 391 update failed: ReferenceError: transform is not defined
    at AISystem.updateHearing (ai-system.js:192:25)
    at AISystem.updateHunter (ai-system.js:119:18)
    at AISystem.update (ai-system.js:80:26)
    at GameEngine.tick (game-engine.js:97:36)
    at GameEngine.update (game-engine.js:64:22)
    at gameLoop (main.js:208:24)
update @ ai-system.js:83
utils.js:167  [Game Error] AI Hunter 391 update failed: ReferenceError: transform is not defined
    at AISystem.updateHearing (ai-system.js:192:25)
    at AISystem.updateHunter (ai-system.js:119:18)
    at AISystem.update (ai-system.js:80:26)
    at GameEngine.tick (game-engine.js:97:36)
    at GameEngine.update (game-engine.js:64:22)
    at gameLoop (main.js:208:24)
error @ utils.js:167
ai-system.js:83  Hunter 391 update failed: ReferenceError: transform is not defined
    at AISystem.updateHearing (ai-system.js:192:25)
    at AISystem.updateHunter (ai-system.js:119:18)
    at AISystem.update (ai-system.js:80:26)
    at GameEngine.tick (game-engine.js:97:36)
    at GameEngine.update (game-engine.js:64:22)
    at gameLoop (main.js:208:24)
update @ ai-system.js:83
utils.js:167  [Game Error] AI Hunter 391 update failed: ReferenceError: transform is not defined
    at AISystem.updateHearing (ai-system.js:192:25)
    at AISystem.updateHunter (ai-system.js:119:18)
    at AISystem.update (ai-system.js:80:26)
    at GameEngine.tick (game-engine.js:97:36)
    at GameEngine.update (game-engine.js:64:22)
    at gameLoop (main.js:208:24)
error @ utils.js:167
ai-system.js:83  Hunter 391 update failed: ReferenceError: transform is not defined
    at AISystem.updateHearing (ai-system.js:192:25)
    at AISystem.updateHunter (ai-system.js:119:18)
    at AISystem.update (ai-system.js:80:26)
    at GameEngine.tick (game-engine.js:97:36)
    at GameEngine.update (game-engine.js:64:22)
    at gameLoop (main.js:208:24)
update @ ai-system.js:83
utils.js:167  [Game Error] AI Hunter 391 update failed: ReferenceError: transform is not defined
    at AISystem.updateHearing (ai-system.js:192:25)
    at AISystem.updateHunter (ai-system.js:119:18)
    at AISystem.update (ai-system.js:80:26)
    at GameEngine.tick (game-engine.js:97:36)
    at GameEngine.update (game-engine.js:64:22)
    at gameLoop (main.js:208:24)
error @ utils.js:167
ai-system.js:83  Hunter 391 update failed: ReferenceError: transform is not defined
    at AISystem.updateHearing (ai-system.js:192:25)
    at AISystem.updateHunter (ai-system.js:119:18)
    at AISystem.update (ai-system.js:80:26)
    at GameEngine.tick (game-engine.js:97:36)
    at GameEngine.update (game-engine.js:64:22)
    at gameLoop (main.js:208:24)
update @ ai-system.js:83
utils.js:167  [Game Error] AI Hunter 391 update failed: ReferenceError: transform is not defined
    at AISystem.updateHearing (ai-system.js:192:25)
    at AISystem.updateHunter (ai-system.js:119:18)
    at AISystem.update (ai-system.js:80:26)
    at GameEngine.tick (game-engine.js:97:36)
    at GameEngine.update (game-engine.js:64:22)
    at gameLoop (main.js:208:24)
error @ utils.js:167
ai-system.js:83  Hunter 391 update failed: ReferenceError: transform is not defined
    at AISystem.updateHearing (ai-system.js:192:25)
    at AISystem.updateHunter (ai-system.js:119:18)
    at AISystem.update (ai-system.js:80:26)
    at GameEngine.tick (game-engine.js:97:36)
    at GameEngine.update (game-engine.js:64:22)
    at gameLoop (main.js:208:24)
update @ ai-system.js:83
utils.js:167  [Game Error] AI Hunter 391 update failed: ReferenceError: transform is not defined
    at AISystem.updateHearing (ai-system.js:192:25)
    at AISystem.updateHunter (ai-system.js:119:18)
    at AISystem.update (ai-system.js:80:26)
    at GameEngine.tick (game-engine.js:97:36)
    at GameEngine.update (game-engine.js:64:22)
    at gameLoop (main.js:208:24)
error @ utils.js:167
ai-system.js:83  Hunter 391 update failed: ReferenceError: transform is not defined
    at AISystem.updateHearing (ai-system.js:192:25)
    at AISystem.updateHunter (ai-system.js:119:18)
    at AISystem.update (ai-system.js:80:26)
    at GameEngine.tick (game-engine.js:97:36)
    at GameEngine.update (game-engine.js:64:22)
    at gameLoop (main.js:208:24)
update @ ai-system.js:83
utils.js:167  [Game Error] AI Hunter 391 update failed: ReferenceError: transform is not defined
    at AISystem.updateHearing (ai-system.js:192:25)
    at AISystem.updateHunter (ai-system.js:119:18)
    at AISystem.update (ai-system.js:80:26)
    at GameEngine.tick (game-engine.js:97:36)
    at GameEngine.update (game-engine.js:64:22)
    at gameLoop (main.js:208:24)
error @ utils.js:167
ai-system.js:83  Hunter 391 update failed: ReferenceError: transform is not defined
    at AISystem.updateHearing (ai-system.js:192:25)
    at AISystem.updateHunter (ai-system.js:119:18)
    at AISystem.update (ai-system.js:80:26)
    at GameEngine.tick (game-engine.js:97:36)
    at GameEngine.update (game-engine.js:64:22)
    at gameLoop (main.js:208:24)
update @ ai-system.js:83
utils.js:167  [Game Error] AI Hunter 391 update failed: ReferenceError: transform is not defined
    at AISystem.updateHearing (ai-system.js:192:25)
    at AISystem.updateHunter (ai-system.js:119:18)
    at AISystem.update (ai-system.js:80:26)
    at GameEngine.tick (game-engine.js:97:36)
    at GameEngine.update (game-engine.js:64:22)
    at gameLoop (main.js:208:24)
error @ utils.js:167
ai-system.js:83  Hunter 391 update failed: ReferenceError: transform is not defined
    at AISystem.updateHearing (ai-system.js:192:25)
    at AISystem.updateHunter (ai-system.js:119:18)
    at AISystem.update (ai-system.js:80:26)
    at GameEngine.tick (game-engine.js:97:36)
    at GameEngine.update (game-engine.js:64:22)
    at gameLoop (main.js:208:24)
update @ ai-system.js:83
utils.js:167  [Game Error] AI Hunter 391 update failed: ReferenceError: transform is not defined
    at AISystem.updateHearing (ai-system.js:192:25)
    at AISystem.updateHunter (ai-system.js:119:18)
    at AISystem.update (ai-system.js:80:26)
    at GameEngine.tick (game-engine.js:97:36)
    at GameEngine.update (game-engine.js:64:22)
    at gameLoop (main.js:208:24)
error @ utils.js:167
ai-system.js:83  Hunter 391 update failed: ReferenceError: transform is not defined
    at AISystem.updateHearing (ai-system.js:192:25)
    at AISystem.updateHunter (ai-system.js:119:18)
    at AISystem.update (ai-system.js:80:26)
    at GameEngine.tick (game-engine.js:97:36)
    at GameEngine.update (game-engine.js:64:22)
    at gameLoop (main.js:208:24)
update @ ai-system.js:83
utils.js:167  [Game Error] AI Hunter 391 update failed: ReferenceError: transform is not defined
    at AISystem.updateHearing (ai-system.js:192:25)
    at AISystem.updateHunter (ai-system.js:119:18)
    at AISystem.update (ai-system.js:80:26)
    at GameEngine.tick (game-engine.js:97:36)
    at GameEngine.update (game-engine.js:64:22)
    at gameLoop (main.js:208:24)
error @ utils.js:167
ai-system.js:83  Hunter 391 update failed: ReferenceError: transform is not defined
    at AISystem.updateHearing (ai-system.js:192:25)
    at AISystem.updateHunter (ai-system.js:119:18)
    at AISystem.update (ai-system.js:80:26)
    at GameEngine.tick (game-engine.js:97:36)
    at GameEngine.update (game-engine.js:64:22)
    at gameLoop (main.js:208:24)
update @ ai-system.js:83
utils.js:167  [Game Error] AI Hunter 391 update failed: ReferenceError: transform is not defined
    at AISystem.updateHearing (ai-system.js:192:25)
    at AISystem.updateHunter (ai-system.js:119:18)
    at AISystem.update (ai-system.js:80:26)
    at GameEngine.tick (game-engine.js:97:36)
    at GameEngine.update (game-engine.js:64:22)
    at gameLoop (main.js:208:24)
error @ utils.js:167
ai-system.js:83  Hunter 391 update failed: ReferenceError: transform is not defined
    at AISystem.updateHearing (ai-system.js:192:25)
    at AISystem.updateHunter (ai-system.js:119:18)
    at AISystem.update (ai-system.js:80:26)
    at GameEngine.tick (game-engine.js:97:36)
    at GameEngine.update (game-engine.js:64:22)
    at gameLoop (main.js:208:24)
update @ ai-system.js:83
utils.js:167  [Game Error] AI Hunter 391 update failed: ReferenceError: transform is not defined
    at AISystem.updateHearing (ai-system.js:192:25)
    at AISystem.updateHunter (ai-system.js:119:18)
    at AISystem.update (ai-system.js:80:26)
    at GameEngine.tick (game-engine.js:97:36)
    at GameEngine.update (game-engine.js:64:22)
    at gameLoop (main.js:208:24)
error @ utils.js:167
ai-system.js:83  Hunter 391 update failed: ReferenceError: transform is not defined
    at AISystem.updateHearing (ai-system.js:192:25)
    at AISystem.updateHunter (ai-system.js:119:18)
    at AISystem.update (ai-system.js:80:26)
    at GameEngine.tick (game-engine.js:97:36)
    at GameEngine.update (game-engine.js:64:22)
    at gameLoop (main.js:208:24)
update @ ai-system.js:83
utils.js:167  [Game Error] AI Hunter 391 update failed: ReferenceError: transform is not defined
    at AISystem.updateHearing (ai-system.js:192:25)
    at AISystem.updateHunter (ai-system.js:119:18)
    at AISystem.update (ai-system.js:80:26)
    at GameEngine.tick (game-engine.js:97:36)
    at GameEngine.update (game-engine.js:64:22)
    at gameLoop (main.js:208:24)
error @ utils.js:167
ai-system.js:83  Hunter 391 update failed: ReferenceError: transform is not defined
    at AISystem.updateHearing (ai-system.js:192:25)
    at AISystem.updateHunter (ai-system.js:119:18)
    at AISystem.update (ai-system.js:80:26)
    at GameEngine.tick (game-engine.js:97:36)
    at GameEngine.update (game-engine.js:64:22)
    at gameLoop (main.js:208:24)
update @ ai-system.js:83
utils.js:167  [Game Error] AI Hunter 391 update failed: ReferenceError: transform is not defined
    at AISystem.updateHearing (ai-system.js:192:25)
    at AISystem.updateHunter (ai-system.js:119:18)
    at AISystem.update (ai-system.js:80:26)
    at GameEngine.tick (game-engine.js:97:36)
    at GameEngine.update (game-engine.js:64:22)
    at gameLoop (main.js:208:24)
error @ utils.js:167
ai-system.js:83  Hunter 391 update failed: ReferenceError: transform is not defined
    at AISystem.updateHearing (ai-system.js:192:25)
    at AISystem.updateHunter (ai-system.js:119:18)
    at AISystem.update (ai-system.js:80:26)
    at GameEngine.tick (game-engine.js:97:36)
    at GameEngine.update (game-engine.js:64:22)
    at gameLoop (main.js:208:24)
update @ ai-system.js:83
utils.js:167  [Game Error] AI Hunter 391 update failed: ReferenceError: transform is not defined
    at AISystem.updateHearing (ai-system.js:192:25)
    at AISystem.updateHunter (ai-system.js:119:18)
    at AISystem.update (ai-system.js:80:26)
    at GameEngine.tick (game-engine.js:97:36)
    at GameEngine.update (game-engine.js:64:22)
    at gameLoop (main.js:208:24)
error @ utils.js:167
ai-system.js:83  Hunter 391 update failed: ReferenceError: transform is not defined
    at AISystem.updateHearing (ai-system.js:192:25)
    at AISystem.updateHunter (ai-system.js:119:18)
    at AISystem.update (ai-system.js:80:26)
    at GameEngine.tick (game-engine.js:97:36)
    at GameEngine.update (game-engine.js:64:22)
    at gameLoop (main.js:208:24)
update @ ai-system.js:83
utils.js:167  [Game Error] AI Hunter 391 update failed: ReferenceError: transform is not defined
    at AISystem.updateHearing (ai-system.js:192:25)
    at AISystem.updateHunter (ai-system.js:119:18)
    at AISystem.update (ai-system.js:80:26)
    at GameEngine.tick (game-engine.js:97:36)
    at GameEngine.update (game-engine.js:64:22)
    at gameLoop (main.js:208:24)
error @ utils.js:167
ai-system.js:83  Hunter 391 update failed: ReferenceError: transform is not defined
    at AISystem.updateHearing (ai-system.js:192:25)
    at AISystem.updateHunter (ai-system.js:119:18)
    at AISystem.update (ai-system.js:80:26)
    at GameEngine.tick (game-engine.js:97:36)
    at GameEngine.update (game-engine.js:64:22)
    at gameLoop (main.js:208:24)
update @ ai-system.js:83
utils.js:167  [Game Error] AI Hunter 391 update failed: ReferenceError: transform is not defined
    at AISystem.updateHearing (ai-system.js:192:25)
    at AISystem.updateHunter (ai-system.js:119:18)
    at AISystem.update (ai-system.js:80:26)
    at GameEngine.tick (game-engine.js:97:36)
    at GameEngine.update (game-engine.js:64:22)
    at gameLoop (main.js:208:24)
error @ utils.js:167
ai-system.js:83  Hunter 391 update failed: ReferenceError: transform is not defined
    at AISystem.updateHearing (ai-system.js:192:25)
    at AISystem.updateHunter (ai-system.js:119:18)
    at AISystem.update (ai-system.js:80:26)
    at GameEngine.tick (game-engine.js:97:36)
    at GameEngine.update (game-engine.js:64:22)
    at gameLoop (main.js:208:24)
update @ ai-system.js:83
utils.js:167  [Game Error] AI Hunter 391 update failed: ReferenceError: transform is not defined
    at AISystem.updateHearing (ai-system.js:192:25)
    at AISystem.updateHunter (ai-system.js:119:18)
    at AISystem.update (ai-system.js:80:26)
    at GameEngine.tick (game-engine.js:97:36)
    at GameEngine.update (game-engine.js:64:22)
    at gameLoop (main.js:208:24)
error @ utils.js:167
ai-system.js:83  Hunter 391 update failed: ReferenceError: transform is not defined
    at AISystem.updateHearing (ai-system.js:192:25)
    at AISystem.updateHunter (ai-system.js:119:18)
    at AISystem.update (ai-system.js:80:26)
    at GameEngine.tick (game-engine.js:97:36)
    at GameEngine.update (game-engine.js:64:22)
    at gameLoop (main.js:208:24)
update @ ai-system.js:83
utils.js:167  [Game Error] AI Hunter 391 update failed: ReferenceError: transform is not defined
    at AISystem.updateHearing (ai-system.js:192:25)
    at AISystem.updateHunter (ai-system.js:119:18)
    at AISystem.update (ai-system.js:80:26)
    at GameEngine.tick (game-engine.js:97:36)
    at GameEngine.update (game-engine.js:64:22)
    at gameLoop (main.js:208:24)
error @ utils.js:167
ai-system.js:83  Hunter 391 update failed: ReferenceError: transform is not defined
    at AISystem.updateHearing (ai-system.js:192:25)
    at AISystem.updateHunter (ai-system.js:119:18)
    at AISystem.update (ai-system.js:80:26)
    at GameEngine.tick (game-engine.js:97:36)
    at GameEngine.update (game-engine.js:64:22)
    at gameLoop (main.js:208:24)
update @ ai-system.js:83
utils.js:167  [Game Error] AI Hunter 391 update failed: ReferenceError: transform is not defined
    at AISystem.updateHearing (ai-system.js:192:25)
    at AISystem.updateHunter (ai-system.js:119:18)
    at AISystem.update (ai-system.js:80:26)
    at GameEngine.tick (game-engine.js:97:36)
    at GameEngine.update (game-engine.js:64:22)
    at gameLoop (main.js:208:24)
error @ utils.js:167
ai-system.js:83  Hunter 391 update failed: ReferenceError: transform is not defined
    at AISystem.updateHearing (ai-system.js:192:25)
    at AISystem.updateHunter (ai-system.js:119:18)
    at AISystem.update (ai-system.js:80:26)
    at GameEngine.tick (game-engine.js:97:36)
    at GameEngine.update (game-engine.js:64:22)
    at gameLoop (main.js:208:24)
update @ ai-system.js:83
utils.js:167  [Game Error] AI Hunter 391 update failed: ReferenceError: transform is not defined
    at AISystem.updateHearing (ai-system.js:192:25)
    at AISystem.updateHunter (ai-system.js:119:18)
    at AISystem.update (ai-system.js:80:26)
    at GameEngine.tick (game-engine.js:97:36)
    at GameEngine.update (game-engine.js:64:22)
    at gameLoop (main.js:208:24)
error @ utils.js:167
ai-system.js:83  Hunter 391 update failed: ReferenceError: transform is not defined
    at AISystem.updateHearing (ai-system.js:192:25)
    at AISystem.updateHunter (ai-system.js:119:18)
    at AISystem.update (ai-system.js:80:26)
    at GameEngine.tick (game-engine.js:97:36)
    at GameEngine.update (game-engine.js:64:22)
    at gameLoop (main.js:208:24)
update @ ai-system.js:83
utils.js:167  [Game Error] AI Hunter 391 update failed: ReferenceError: transform is not defined
    at AISystem.updateHearing (ai-system.js:192:25)
    at AISystem.updateHunter (ai-system.js:119:18)
    at AISystem.update (ai-system.js:80:26)
    at GameEngine.tick (game-engine.js:97:36)
    at GameEngine.update (game-engine.js:64:22)
    at gameLoop (main.js:208:24)
error @ utils.js:167
ai-system.js:83  Hunter 391 update failed: ReferenceError: transform is not defined
    at AISystem.updateHearing (ai-system.js:192:25)
    at AISystem.updateHunter (ai-system.js:119:18)
    at AISystem.update (ai-system.js:80:26)
    at GameEngine.tick (game-engine.js:97:36)
    at GameEngine.update (game-engine.js:64:22)
    at gameLoop (main.js:208:24)
update @ ai-system.js:83
utils.js:167  [Game Error] AI Hunter 391 update failed: ReferenceError: transform is not defined
    at AISystem.updateHearing (ai-system.js:192:25)
    at AISystem.updateHunter (ai-system.js:119:18)
    at AISystem.update (ai-system.js:80:26)
    at GameEngine.tick (game-engine.js:97:36)
    at GameEngine.update (game-engine.js:64:22)
    at gameLoop (main.js:208:24)
error @ utils.js:167
ai-system.js:83  Hunter 391 update failed: ReferenceError: transform is not defined
    at AISystem.updateHearing (ai-system.js:192:25)
    at AISystem.updateHunter (ai-system.js:119:18)
    at AISystem.update (ai-system.js:80:26)
    at GameEngine.tick (game-engine.js:97:36)
    at GameEngine.update (game-engine.js:64:22)
    at gameLoop (main.js:208:24)
update @ ai-system.js:83
utils.js:167  [Game Error] AI Hunter 391 update failed: ReferenceError: transform is not defined
    at AISystem.updateHearing (ai-system.js:192:25)
    at AISystem.updateHunter (ai-system.js:119:18)
    at AISystem.update (ai-system.js:80:26)
    at GameEngine.tick (game-engine.js:97:36)
    at GameEngine.update (game-engine.js:64:22)
    at gameLoop (main.js:208:24)
error @ utils.js:167
ai-system.js:83  Hunter 391 update failed: ReferenceError: transform is not defined
    at AISystem.updateHearing (ai-system.js:192:25)
    at AISystem.updateHunter (ai-system.js:119:18)
    at AISystem.update (ai-system.js:80:26)
    at GameEngine.tick (game-engine.js:97:36)
    at GameEngine.update (game-engine.js:64:22)
    at gameLoop (main.js:208:24)
update @ ai-system.js:83
ai-system.js:162 🎧 Hearing Check: Distance=9.25m, EffectiveRange=15.30m, PlayerSpeed=0.105, SoundLevel=0.805
utils.js:167  [Game Error] AI Hunter 391 update failed: ReferenceError: transform is not defined
    at AISystem.updateHearing (ai-system.js:192:25)
    at AISystem.updateHunter (ai-system.js:119:18)
    at AISystem.update (ai-system.js:80:26)
    at GameEngine.tick (game-engine.js:97:36)
    at GameEngine.update (game-engine.js:64:22)
    at gameLoop (main.js:208:24)
error @ utils.js:167
ai-system.js:83  Hunter 391 update failed: ReferenceError: transform is not defined
    at AISystem.updateHearing (ai-system.js:192:25)
    at AISystem.updateHunter (ai-system.js:119:18)
    at AISystem.update (ai-system.js:80:26)
    at GameEngine.tick (game-engine.js:97:36)
    at GameEngine.update (game-engine.js:64:22)
    at gameLoop (main.js:208:24)
update @ ai-system.js:83
ai-system.js:499 [VISION DEBUG] Object
utils.js:167  [Game Error] AI Hunter 391 update failed: ReferenceError: transform is not defined
    at AISystem.updateHearing (ai-system.js:192:25)
    at AISystem.updateHunter (ai-system.js:119:18)
    at AISystem.update (ai-system.js:80:26)
    at GameEngine.tick (game-engine.js:97:36)
    at GameEngine.update (game-engine.js:64:22)
    at gameLoop (main.js:208:24)
error @ utils.js:167
ai-system.js:83  Hunter 391 update failed: ReferenceError: transform is not defined
    at AISystem.updateHearing (ai-system.js:192:25)
    at AISystem.updateHunter (ai-system.js:119:18)
    at AISystem.update (ai-system.js:80:26)
    at GameEngine.tick (game-engine.js:97:36)
    at GameEngine.update (game-engine.js:64:22)
    at gameLoop (main.js:208:24)
update @ ai-system.js:83
utils.js:167  [Game Error] AI Hunter 391 update failed: ReferenceError: transform is not defined
    at AISystem.updateHearing (ai-system.js:192:25)
    at AISystem.updateHunter (ai-system.js:119:18)
    at AISystem.update (ai-system.js:80:26)
    at GameEngine.tick (game-engine.js:97:36)
    at GameEngine.update (game-engine.js:64:22)
    at gameLoop (main.js:208:24)
error @ utils.js:167
ai-system.js:83  Hunter 391 update failed: ReferenceError: transform is not defined
    at AISystem.updateHearing (ai-system.js:192:25)
    at AISystem.updateHunter (ai-system.js:119:18)
    at AISystem.update (ai-system.js:80:26)
    at GameEngine.tick (game-engine.js:97:36)
    at GameEngine.update (game-engine.js:64:22)
    at gameLoop (main.js:208:24)
update @ ai-system.js:83
utils.js:167  [Game Error] AI Hunter 391 update failed: ReferenceError: transform is not defined
    at AISystem.updateHearing (ai-system.js:192:25)
    at AISystem.updateHunter (ai-system.js:119:18)
    at AISystem.update (ai-system.js:80:26)
    at GameEngine.tick (game-engine.js:97:36)
    at GameEngine.update (game-engine.js:64:22)
    at gameLoop (main.js:208:24)
error @ utils.js:167
ai-system.js:83  Hunter 391 update failed: ReferenceError: transform is not defined
    at AISystem.updateHearing (ai-system.js:192:25)
    at AISystem.updateHunter (ai-system.js:119:18)
    at AISystem.update (ai-system.js:80:26)
    at GameEngine.tick (game-engine.js:97:36)
    at GameEngine.update (game-engine.js:64:22)
    at gameLoop (main.js:208:24)
update @ ai-system.js:83
utils.js:167  [Game Error] AI Hunter 391 update failed: ReferenceError: transform is not defined
    at AISystem.updateHearing (ai-system.js:192:25)
    at AISystem.updateHunter (ai-system.js:119:18)
    at AISystem.update (ai-system.js:80:26)
    at GameEngine.tick (game-engine.js:97:36)
    at GameEngine.update (game-engine.js:64:22)
    at gameLoop (main.js:208:24)
error @ utils.js:167
ai-system.js:83  Hunter 391 update failed: ReferenceError: transform is not defined
    at AISystem.updateHearing (ai-system.js:192:25)
    at AISystem.updateHunter (ai-system.js:119:18)
    at AISystem.update (ai-system.js:80:26)
    at GameEngine.tick (game-engine.js:97:36)
    at GameEngine.update (game-engine.js:64:22)
    at gameLoop (main.js:208:24)
update @ ai-system.js:83
utils.js:167  [Game Error] AI Hunter 391 update failed: ReferenceError: transform is not defined
    at AISystem.updateHearing (ai-system.js:192:25)
    at AISystem.updateHunter (ai-system.js:119:18)
    at AISystem.update (ai-system.js:80:26)
    at GameEngine.tick (game-engine.js:97:36)
    at GameEngine.update (game-engine.js:64:22)
    at gameLoop (main.js:208:24)
error @ utils.js:167
ai-system.js:83  Hunter 391 update failed: ReferenceError: transform is not defined
    at AISystem.updateHearing (ai-system.js:192:25)
    at AISystem.updateHunter (ai-system.js:119:18)
    at AISystem.update (ai-system.js:80:26)
    at GameEngine.tick (game-engine.js:97:36)
    at GameEngine.update (game-engine.js:64:22)
    at gameLoop (main.js:208:24)
update @ ai-system.js:83
utils.js:167  [Game Error] AI Hunter 391 update failed: ReferenceError: transform is not defined
    at AISystem.updateHearing (ai-system.js:192:25)
    at AISystem.updateHunter (ai-system.js:119:18)
    at AISystem.update (ai-system.js:80:26)
    at GameEngine.tick (game-engine.js:97:36)
    at GameEngine.update (game-engine.js:64:22)
    at gameLoop (main.js:208:24)
error @ utils.js:167
ai-system.js:83  Hunter 391 update failed: ReferenceError: transform is not defined
    at AISystem.updateHearing (ai-system.js:192:25)
    at AISystem.updateHunter (ai-system.js:119:18)
    at AISystem.update (ai-system.js:80:26)
    at GameEngine.tick (game-engine.js:97:36)
    at GameEngine.update (game-engine.js:64:22)
    at gameLoop (main.js:208:24)
update @ ai-system.js:83
utils.js:158 [Game] AI reaction complete! RACE TO CAN BEGINS! 
ai-system.js:215 🎧 AI hears player but is in RACE state (can't investigate)
ai-system.js:215 🎧 AI hears player but is in RACE state (can't investigate)
ai-system.js:215 🎧 AI hears player but is in RACE state (can't investigate)
ai-system.js:215 🎧 AI hears player but is in RACE state (can't investigate)
ai-system.js:215 🎧 AI hears player but is in RACE state (can't investigate)
ai-system.js:215 🎧 AI hears player but is in RACE state (can't investigate)
ai-system.js:215 🎧 AI hears player but is in RACE state (can't investigate)
ai-system.js:215 🎧 AI hears player but is in RACE state (can't investigate)
ai-system.js:215 🎧 AI hears player but is in RACE state (can't investigate)
ai-system.js:215 🎧 AI hears player but is in RACE state (can't investigate)
ai-system.js:215 🎧 AI hears player but is in RACE state (can't investigate)
ai-system.js:215 🎧 AI hears player but is in RACE state (can't investigate)
ai-system.js:215 🎧 AI hears player but is in RACE state (can't investigate)
ai-system.js:215 🎧 AI hears player but is in RACE state (can't investigate)
ai-system.js:215 🎧 AI hears player but is in RACE state (can't investigate)
ai-system.js:215 🎧 AI hears player but is in RACE state (can't investigate)
ai-system.js:215 🎧 AI hears player but is in RACE state (can't investigate)
ai-system.js:215 🎧 AI hears player but is in RACE state (can't investigate)
ai-system.js:215 🎧 AI hears player but is in RACE state (can't investigate)
ai-system.js:215 🎧 AI hears player but is in RACE state (can't investigate)
ai-system.js:215 🎧 AI hears player but is in RACE state (can't investigate)
ai-system.js:215 🎧 AI hears player but is in RACE state (can't investigate)
ai-system.js:215 🎧 AI hears player but is in RACE state (can't investigate)
ai-system.js:215 🎧 AI hears player but is in RACE state (can't investigate)
ai-system.js:215 🎧 AI hears player but is in RACE state (can't investigate)
ai-system.js:215 🎧 AI hears player but is in RACE state (can't investigate)
ai-system.js:215 🎧 AI hears player but is in RACE state (can't investigate)
ai-system.js:215 🎧 AI hears player but is in RACE state (can't investigate)
utils.js:158 [Game] Key down: ArrowLeft -> left 
ai-system.js:215 🎧 AI hears player but is in RACE state (can't investigate)
ai-system.js:215 🎧 AI hears player but is in RACE state (can't investigate)
ai-system.js:215 🎧 AI hears player but is in RACE state (can't investigate)
ai-system.js:215 🎧 AI hears player but is in RACE state (can't investigate)
ai-system.js:215 🎧 AI hears player but is in RACE state (can't investigate)
ai-system.js:215 🎧 AI hears player but is in RACE state (can't investigate)
ai-system.js:215 🎧 AI hears player but is in RACE state (can't investigate)
ai-system.js:215 🎧 AI hears player but is in RACE state (can't investigate)
ai-system.js:215 🎧 AI hears player but is in RACE state (can't investigate)
ai-system.js:215 🎧 AI hears player but is in RACE state (can't investigate)
ai-system.js:215 🎧 AI hears player but is in RACE state (can't investigate)
ai-system.js:215 🎧 AI hears player but is in RACE state (can't investigate)
ai-system.js:215 🎧 AI hears player but is in RACE state (can't investigate)
ai-system.js:215 🎧 AI hears player but is in RACE state (can't investigate)
ai-system.js:215 🎧 AI hears player but is in RACE state (can't investigate)
ai-system.js:215 🎧 AI hears player but is in RACE state (can't investigate)
ai-system.js:215 🎧 AI hears player but is in RACE state (can't investigate)
ai-system.js:215 🎧 AI hears player but is in RACE state (can't investigate)
ai-system.js:215 🎧 AI hears player but is in RACE state (can't investigate)
ai-system.js:215 🎧 AI hears player but is in RACE state (can't investigate)
ai-system.js:215 🎧 AI hears player but is in RACE state (can't investigate)
ai-system.js:215 🎧 AI hears player but is in RACE state (can't investigate)
ai-system.js:215 🎧 AI hears player but is in RACE state (can't investigate)
ai-system.js:215 🎧 AI hears player but is in RACE state (can't investigate)
ai-system.js:215 🎧 AI hears player but is in RACE state (can't investigate)
ai-system.js:162 🎧 Hearing Check: Distance=6.07m, EffectiveRange=16.30m, PlayerSpeed=0.112, SoundLevel=0.858
ai-system.js:215 🎧 AI hears player but is in RACE state (can't investigate)
ai-system.js:215 🎧 AI hears player but is in RACE state (can't investigate)
ai-system.js:215 🎧 AI hears player but is in RACE state (can't investigate)
ai-system.js:215 🎧 AI hears player but is in RACE state (can't investigate)
ai-system.js:215 🎧 AI hears player but is in RACE state (can't investigate)
ai-system.js:215 🎧 AI hears player but is in RACE state (can't investigate)
utils.js:158 [Game] Key down: ArrowLeft -> left 
ai-system.js:215 🎧 AI hears player but is in RACE state (can't investigate)
ai-system.js:215 🎧 AI hears player but is in RACE state (can't investigate)
utils.js:158 [Game] Key down: ArrowLeft -> left 
ai-system.js:215 🎧 AI hears player but is in RACE state (can't investigate)
ai-system.js:215 🎧 AI hears player but is in RACE state (can't investigate)
utils.js:158 [Game] Key down: ArrowLeft -> left 
ai-system.js:215 🎧 AI hears player but is in RACE state (can't investigate)
utils.js:158 [Game] Key down: ArrowLeft -> left 
ai-system.js:215 🎧 AI hears player but is in RACE state (can't investigate)
ai-system.js:215 🎧 AI hears player but is in RACE state (can't investigate)
utils.js:158 [Game] Key down: ArrowLeft -> left 
ai-system.js:215 🎧 AI hears player but is in RACE state (can't investigate)
utils.js:158 [Game] AI reached can first! AI WINS the race! 
utils.js:158 [Game] AI Won! Player was too slow to reach the can. 
utils.js:158 [Game] Game phase: playing -> game_over 
utils.js:158 [Game] Game phase: game_over -> game_over 
ai-system.js:215 🎧 AI hears player but is in RACE state (can't investigate)
utils.js:158 [Game] Key down: ArrowLeft -> left 
utils.js:158 [Game] Key down: ArrowLeft -> left 
utils.js:158 [Game] Key down: ArrowLeft -> left 
utils.js:158 [Game] Key down: ArrowLeft -> left 
utils.js:158 [Game] Key down: ArrowLeft -> left 
utils.js:158 [Game] Key down: ArrowLeft -> left 
utils.js:158 [Game] Key down: ArrowLeft -> left 
utils.js:158 [Game] Canvas resized to: 2114x1314 
[NEW] Explain Console errors by using Copilot in Edge: click
         
         to explain an error. 
        Learn more
        Don't show again
