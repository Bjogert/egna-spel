1: The IA hunter must identify the player that is hiding. so just catching a glint of the player wont do. It must be certain who it is. Maybe each player gets a number in the shirt like in football? 


2: The AI hunters view cone can get wider the slower it moves and narrow the faster it moves.

3. the player should not be able to see the "hunter" behind the obstacles. (like project zomboid) 